package model

open abstract class Persona ( var id: Int, var nombre: String,){



}